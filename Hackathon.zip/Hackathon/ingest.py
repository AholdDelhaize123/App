import os
import certifi

os.environ["SSL_CERT_FILE"] = certifi.where()

import chromadb
from langchain_openai import OpenAIEmbeddings
from src.config import CHROMA_DB_DIR, OPENAI_API_KEY
from src.preprocess import load_and_split_data

client = chromadb.PersistentClient(path=CHROMA_DB_DIR)

collection = client.get_or_create_collection(name="travel_docs")

embedding_model = OpenAIEmbeddings(
    openai_api_key=OPENAI_API_KEY,
    model="text-embedding-3-small"
)

documents = load_and_split_data()

texts = [doc["text"] for doc in documents]
metadatas = [doc["metadata"] for doc in documents]

embeddings = embedding_model.embed_documents(texts)

ids = [str(i) for i in range(len(texts))]

collection.add(
    documents=texts,
    embeddings=embeddings,
    metadatas=metadatas,
    ids=ids
)

print("✅ Data stored in ChromaDB")