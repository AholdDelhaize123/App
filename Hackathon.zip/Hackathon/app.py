import streamlit as st
from src.rag_query import get_travel_docs

# Page configuration
st.set_page_config(
    page_title="Travel Document Advisor",
    page_icon="✈️",
    layout="centered"
)

# Header
st.markdown(
    """
    <h1 style='text-align: center; color: #2E86C1;'>
    ✈️ Travel Document Advisor
    </h1>
    <p style='text-align: center; font-size:18px;'>
    Check the documents required for international travel
    </p>
    """,
    unsafe_allow_html=True
)

st.divider()

# Input section
st.subheader("Enter Your Travel Route")

col1, col2 = st.columns(2)

with col1:
    from_country = st.text_input("🌍 From Country")

with col2:
    to_country = st.text_input("🛬 To Country")

st.write("")

# Button
if st.button("🔍 Check Required Documents", use_container_width=True):

    if from_country and to_country:

        query = f"Travel from {from_country} to {to_country}"

        with st.spinner("Checking travel requirements..."):
            response = get_travel_docs(query)

        st.success("Documents Found!")

        st.markdown("### 📄 Required Travel Documents")
        st.info(response)

    else:
        st.warning("⚠️ Please enter both countries.")

st.divider()

# Footer
st.markdown(
    """
    <p style='text-align: center; font-size:14px; color:gray;'>
    Powered by AI ✨ | RAG + ChromaDB + OpenAI
    </p>
    """,
    unsafe_allow_html=True
)