import os

OPENAI_API_KEY = "sk-MS25a_RdXnqa1A6np1b7jA"

CHROMA_DB_DIR = os.path.join(os.getcwd(), "chroma_db")

DATA_FILE = os.path.join(os.getcwd(), "data", "travel_documents.csv")

EMBEDDING_MODEL_NAME = "text-embedding-3-small"