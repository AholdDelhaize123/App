from langchain_openai import OpenAIEmbeddings
import chromadb
import httpx
import urllib3
import requests

from .config import CHROMA_DB_DIR, OPENAI_API_KEY
from .preprocess import load_and_split_data


# =========================
# SSL FIX
# =========================

requests.packages.urllib3.disable_warnings()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# httpx client that ignores SSL verification
client = httpx.Client(verify=False)


# =========================
# CREATE CHROMA COLLECTION
# =========================

def create_chroma_collection():

    documents = load_and_split_data()

    # Persistent Chroma client
    client_db = chromadb.PersistentClient(path=CHROMA_DB_DIR)

    collection = client_db.get_or_create_collection(
        name="travel_docs"
    )

    # Embedding model with SSL disabled
    embedding_model = OpenAIEmbeddings(
        api_key=OPENAI_API_KEY,
        model="text-embedding-3-small",
        http_client=client
    )

    texts = [doc["text"] for doc in documents]
    metadatas = [doc["metadata"] for doc in documents]

    print("Total documents:", len(texts))
    print("First document:", texts[0])

    # Create embeddings
    embeddings = embedding_model.embed_documents(texts)

    print("Embedding size:", len(embeddings[0]))

    ids = [str(i) for i in range(len(texts))]

    # Store in Chroma
    collection.add(
        documents=texts,
        embeddings=embeddings,
        metadatas=metadatas,
        ids=ids
    )

    print("Documents stored:", collection.count())
    print("✅ Chroma DB populated successfully")


# =========================
# MAIN
# =========================

if __name__ == "__main__":
    create_chroma_collection()