import os
import chromadb
import certifi
from langchain_openai import OpenAIEmbeddings
from openai import OpenAI
from .config import CHROMA_DB_DIR, OPENAI_API_KEY

# Fix SSL issue
os.environ["SSL_CERT_FILE"] = certifi.where()

# Set API key
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# OpenAI client
client_openai = OpenAI()

# ChromaDB
client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
collection = client.get_or_create_collection(name="travel_docs")

# Embedding model
embedding_model = OpenAIEmbeddings()

def get_travel_docs(query, top_k=3):

    # Create query embedding
    query_embedding = embedding_model.embed_query(query)

    # Search vector DB
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k
    )

    context = " ".join(results["documents"][0]) if results["documents"] else "No data found."

    prompt = f"""
User question: {query}

Answer ONLY about travel documents.

Context:
{context}
"""

    response = client_openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content