import pandas as pd
from langchain_text_splitters import RecursiveCharacterTextSplitter
from .config import DATA_FILE   # <-- relative import

def load_and_split_data():
    df = pd.read_csv(DATA_FILE)
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    
    documents = []
    for i, row in df.iterrows():
        text = f"Travel from {row['From_Country']} to {row['To_Country']} requires: {row['Documents_Required']}. Notes: {row['Notes']}"
        chunks = splitter.split_text(text)
        for chunk in chunks:
            documents.append({'text': chunk, 'metadata': {'from': row['From_Country'], 'to': row['To_Country']}})
    
    
    return documents

if __name__ == "__main__":
    docs = load_and_split_data()
    print("\nTotal chunks created:", len(docs))

    # Print each chunk
    for i, doc in enumerate(docs, 1):
        print(f"\nChunk {i} (from {doc['metadata']['from']} to {doc['metadata']['to']}):")
        print(doc['text'])