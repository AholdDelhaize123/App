import os
import httpx
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

print("Step 1: Loading env")

load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY")

print("Step 2: Creating HTTP client")

client = httpx.Client(verify=False)

print("Step 3: Loading embedding model")

embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in/v1",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=API_KEY,
    http_client=client
)

texts = [
    "Travel from India to UK requires passport and visa",
    "Travel from USA to India requires passport"
]

print("Step 4: Creating FAISS index")

vectorstore = FAISS.from_texts(texts, embedding_model)

print("Step 5: FAISS index created successfully")