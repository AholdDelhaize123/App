import streamlit as st
import sys
import os

# Add src folder to path
sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from faiss_store import build_faiss_index
from rag_query import get_travel_docs


st.set_page_config(
    page_title="Travel Document Advisor",
    page_icon="✈️",
    layout="centered"
)

st.title("✈️ Travel Document Advisor")
st.markdown("Find the **required documents** for international travel using AI.")


# ---------- LOAD FAISS ONLY ONCE ----------
@st.cache_resource
def load_index():
    # build_faiss_index()
    return True


load_index()

st.divider()

# ---------- INPUT SECTION ----------
st.subheader("🌍 Enter Travel Route")

col1, col2 = st.columns(2)

with col1:
    from_country = st.text_input("From Country")

with col2:
    to_country = st.text_input("To Country")


# ---------- QUERY BUTTON ----------
if st.button("🔍 Check Documents"):

    if not from_country or not to_country:
        st.warning("Please enter both countries.")
    else:

        query = f"Travel from {from_country} to {to_country}"

        with st.spinner("Checking travel requirements..."):

            answer = get_travel_docs(query)

        st.success("Results Found")

        st.markdown("### 📄 Required Documents")
        st.info(answer)


# ---------- FOOTER ----------
st.divider()
st.caption("Built with FAISS + LangChain + GPT-4o Mini")