import os
import httpx
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings

print("STEP 2.1: Loading .env")

load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")

print("STEP 2.2: API key loaded")

# Create HTTP client with timeout
client = httpx.Client(
    verify=False,
    timeout=30
)

print("STEP 2.3: Creating embedding model")

embedding = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in/v1",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=api_key,
    http_client=client
)

print("STEP 2.4: Generating embedding")

try:
    vector = embedding.embed_query("Travel from India to UK")

    print("STEP 2.5: Embedding received")
    print("Embedding vector length:", len(vector))

except Exception as e:
    print("EMBEDDING ERROR:", e)