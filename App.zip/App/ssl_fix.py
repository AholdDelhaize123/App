# import os

# tiktoken_cache_dir = "./tiktoken_cache"
# os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

# # validate
# assert os.path.exists(os.path.join(tiktoken_cache_dir,"9b5ad71b2ce5302211f9c61530b329a4922fc6a4"))

import os

# Set tokenizer cache directory
tiktoken_cache_dir = os.path.abspath("tiktoken_cache")
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

# Print for debugging
print("Using tiktoken cache directory:", tiktoken_cache_dir)

# Show files inside cache
if os.path.exists(tiktoken_cache_dir):
    print("Cache files:", os.listdir(tiktoken_cache_dir))
else:
    print("tiktoken_cache folder not found!")