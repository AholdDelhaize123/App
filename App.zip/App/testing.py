from langchain_openai import ChatOpenAI, OpenAIEmbeddings
import httpx
import os
import urllib3
import numpy as np

tiktoken_cache_dir = "./tiktoken_cache"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir
# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# Use Client for compatibility with langchain-openai 0.0.8
client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in/v1",
    model="azure/genailab-maas-gpt-4o-mini",
    api_key="sk-MS25a_RdXnqa1A6np1b7jA",  # Replace with your actual API key
    http_client=client
)

embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key="sk-MS25a_RdXnqa1A6np1b7jA",  # Replace with your actual API key
    http_client=client
)

print(llm.invoke('Tell me about urself').content)

# Texts to compare
text1 = "LangChain helps build applications with LLMs."
text2 = "LangChain is a framework for developing language model applications."

# Get embeddings
embedding1 = embedding_model.embed_query(text1)
embedding2 = embedding_model.embed_query(text2)

# Compute cosine similarity
def cosine_similarity(a, b):
    a = np.array(a)
    b = np.array(b)
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

similarity = cosine_similarity(embedding1, embedding2)

print(f"Cosine Similarity: {similarity:.4f}")

#DON'T EDIT THIS FILE

# [SSLError] [SSL: CERTIFICATE_VERIFY_FAILED] 
# https://stackoverflow.com/questions/76106366/how-to-use-tiktoken-in-offline-mode-computer