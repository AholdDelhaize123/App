import os
import httpx
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

# Load .env file
load_dotenv()

# Get API key from .env
API_KEY = os.getenv("OPENAI_API_KEY")

print("API Key Loaded:", API_KEY[:5], "...")

# Create HTTP client (avoids SSL issues)
client = httpx.Client(verify=False)

# Initialize LLM
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in/v1",
    model="azure/genailab-maas-gpt-4o-mini",
    api_key=API_KEY,
    http_client=client
)

print("Sending request to model...")

response = llm.invoke("Hello, introduce yourself")

print("\nResponse:")
print(response.content)