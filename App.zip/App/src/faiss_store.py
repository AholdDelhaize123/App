import os
import httpx
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from preprocess import load_documents

print("FAISS FILE LOADED")

load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY")

client = httpx.Client(verify=False)

embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in/v1",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=API_KEY,
    http_client=client
)


def build_faiss_index():

    print("STEP 1: Loading documents")

    docs = load_documents()

    print("STEP 2: Documents loaded:", len(docs))

    texts = [doc.page_content for doc in docs]

    print("STEP 3: Creating FAISS embeddings")

    vectorstore = FAISS.from_texts(texts, embedding_model)

    print("STEP 4: Saving FAISS index")

    vectorstore.save_local("faiss_index")

    print("STEP 5: FAISS index created")


if __name__ == "__main__":
    build_faiss_index()