import os
import httpx
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

print("RAG FILE LOADED")

# Load environment variables
load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY")

# HTTP client (SSL disabled for corporate network)
client = httpx.Client(verify=False)

# -----------------------------
# Embedding Model
# -----------------------------
print("Loading embedding model...")

embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in/v1",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=API_KEY,
    http_client=client
)

# -----------------------------
# Load FAISS Index
# -----------------------------
print("STEP 1: Loading FAISS index")

vectorstore = FAISS.load_local(
    "faiss_index",
    embedding_model,
    allow_dangerous_deserialization=True
)

print("FAISS index loaded successfully")

# -----------------------------
# Load LLM
# -----------------------------
print("STEP 2: Loading LLM")

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in/v1",
    model="azure/genailab-maas-gpt-4o-mini",
    api_key=API_KEY,
    http_client=client
)

print("LLM loaded successfully")

# -----------------------------
# RAG FUNCTION
# -----------------------------
def get_travel_docs(query):

    print("STEP 3: Searching vector DB...")
    print("Creating query embedding...")

    docs = vectorstore.similarity_search(query, k=2)

    print("Documents retrieved:", len(docs))

    context = "\n".join([doc.page_content for doc in docs])

    prompt = f"""
Based on the following travel information:

{context}

Answer the user's question:
{query}
"""

    print("STEP 4: Sending prompt to LLM")

    response = llm.invoke(prompt)

    print("LLM response received")

    return response.content


# -----------------------------
# Test Run
# -----------------------------
if __name__ == "__main__":

    question = "What documents are required to travel from India to UK?"

    answer = get_travel_docs(question)

    print("\nANSWER:\n", answer)