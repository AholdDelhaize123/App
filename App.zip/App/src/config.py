import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DATA_FILE = os.path.join(os.getcwd(), "data", "travel_documents.csv")
FAISS_INDEX_DIR = os.path.join(os.getcwd(), "faiss_index")  # Path to save FAISS