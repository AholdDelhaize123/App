import pandas as pd
from langchain.schema import Document

DATA_FILE = "data/travel_documents.csv"


def load_documents():

    df = pd.read_csv(DATA_FILE)

    docs = []

    for _, row in df.iterrows():

        text = f"Travel from {row['From_Country']} to {row['To_Country']} requires: {row['Documents_Required']}. Notes: {row['Notes']}"

        docs.append(Document(page_content=text))

    return docs


if __name__ == "__main__":

    docs = load_documents()

    print("Total documents:", len(docs))
    print("First document:", docs[0].page_content)